<?php
/*
Plugin Name: Hanzi Handwriting + Glossary Inline Redirect
Description: Viết tay chữ Hán hiển thị trong popup và bấm ký tự để vào trang Glossary by Codeat.
Version: 2.4
Author: Bạn
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// --- PHẦN NÀY KHÔNG THAY ĐỔI ---
/**
 * Nạp các file script và style cần thiết cho plugin.
 */
function hanzi_enqueue_scripts_inline() {
    wp_enqueue_script( 'handwriting-canvas', plugin_dir_url( __FILE__ ) . 'js/handwriting.canvas.js', array(), '1.0', true );
    wp_enqueue_script( 'hanzi-init', plugin_dir_url( __FILE__ ) . 'js/hanzi-init.js', array('handwriting-canvas'), '2.0', true );
    wp_enqueue_style( 'hanzi-style', plugin_dir_url( __FILE__ ) . 'style.css' );
}
add_action( 'wp_enqueue_scripts', 'hanzi_enqueue_scripts_inline' );

/**
 * Truyền dữ liệu từ PHP sang JavaScript một cách an toàn.
 */
function hanzi_localize_script_inline() {
    wp_localize_script('hanzi-init', 'hanziAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'), 
        'home_url' => home_url('/')
    ));
}
add_action('wp_enqueue_scripts', 'hanzi_localize_script_inline');


// --- BẮT ĐẦU PHẦN MÃ ĐƯỢC CẬP NHẬT ---

/**
 * Tạo shortcode [hanzi_popup_trigger] để hiển thị biểu tượng kích hoạt popup.
 * Bạn có thể đặt shortcode này ở bất cứ đâu bạn muốn.
 */
function hanzi_popup_trigger_shortcode() {
    // Thay 'URL_HÌNH_ẢNH_CỦA_BẠN' bằng link ảnh bạn vừa sao chép
    $imageUrl = 'https://tiengtrungquoc.net/wp-content/uploads/2025/12/pen.png';

    // Thẻ <img> này sẽ là icon của bạn.
    // Điều quan trọng là phải giữ lại id="open-hanzi-popup"
    return '<img id="open-hanzi-popup" src="' . esc_url($imageUrl) . '" alt="Viết tay chữ Hán" style="cursor: pointer; width: 28px; height: 28px;" />';
}
add_shortcode( 'hanzi_popup_trigger', 'hanzi_popup_trigger_shortcode' );

/**
 * Chèn HTML của popup vẽ chữ vào chân trang (wp_footer).
 * Popup này sẽ được ẩn đi bằng CSS và chỉ hiện ra khi người dùng nhấp vào trigger.
 */
function hanzi_add_popup_to_footer() {
    ?>
    <div id="hanzi-popup-overlay" class="hanzi-popup"></div>
    <div id="hanzi-popup-modal" class="hanzi-popup">
        <button id="hanzi-popup-close" title="Đóng">&times;</button>
        <div class="hanzi-container">
            <h3>Viết chữ Hán</h3>
            <canvas id="handwriting-canvas" width="300" height="300" style="border:1px solid #000; touch-action: none;"></canvas>
            <div>
                <button id="clear-canvas">Xóa</button>
            </div>
            <div>
                <strong>Kết quả:</strong>
                <div id="hanzi-result"></div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'hanzi_add_popup_to_footer' );

// --- KẾT THÚC PHẦN MÃ ĐƯỢC CẬP NHẬT ---


// --- PHẦN NÀY KHÔNG THAY ĐỔI ---
/**
 * Lọc kết quả tìm kiếm để chỉ tìm trong tiêu đề cho Custom Post Type 'glossary'.
 */
function hanzi_search_by_title_only( $search, $query ) {
    global $wpdb;
    if ( ! is_admin() && $query->is_search() && $query->get('post_type') === 'glossary' ) {
        $search_term = $query->get('s');
        if ( ! empty( $search_term ) ) {
            $search = $wpdb->prepare(
                " AND $wpdb->posts.post_title LIKE %s ",
                '%' . $wpdb->esc_like( $search_term ) . '%'
            );
        }
    }
    return $search;
}
add_filter( 'posts_search', 'hanzi_search_by_title_only', 10, 2 );

?>