document.addEventListener('DOMContentLoaded', function () {
    
    // --- BẮT ĐẦU PHẦN MÃ MỚI ĐỂ ĐIỀU KHIỂN POPUP ---
    const openTrigger = document.getElementById('open-hanzi-popup');
    const closeButton = document.getElementById('hanzi-popup-close');
    const overlay = document.getElementById('hanzi-popup-overlay');
    const clearButton = document.getElementById('clear-canvas');

    // Hàm để đóng popup
    function closePopup() {
        document.body.classList.remove('hanzi-popup-active');
        // Tự động xóa canvas khi đóng để lần mở sau canvas trống
        if (clearButton) {
            clearButton.click();
        }
    }

    // Gán sự kiện cho các phần tử
    if (openTrigger) {
        openTrigger.addEventListener('click', function() {
            document.body.classList.add('hanzi-popup-active');
        });
    }

    if (closeButton) {
        closeButton.addEventListener('click', closePopup);
    }

    if (overlay) {
        overlay.addEventListener('click', closePopup);
    }

    // --- KẾT THÚC PHẦN MÃ MỚI ĐỂ ĐIỀU KHIỂN POPUP ---


    // --- PHẦN MÃ XỬ LÝ CANVAS GIỮ NGUYÊN ---
    const canvasElement = document.getElementById('handwriting-canvas');
    if (!canvasElement) return;

    const can = new handwriting.Canvas(canvasElement);
    can.setOptions({
        language: 'zh_TW', // hoặc 'zh_CN'
        numOfReturn: 5
    });

    can.setCallBack(function (result, err) {
        if (err) {
            console.error(err);
            const resultDiv = document.getElementById('hanzi-result');
            resultDiv.innerHTML = '<span style="color: red;">Lỗi nhận dạng!</span>';
        } else {
            const resultDiv = document.getElementById('hanzi-result');
            resultDiv.innerHTML = '';
            result.forEach(char => {
                const span = document.createElement('span');
                span.textContent = char;
                span.style.fontSize = '2em';
                span.style.margin = '5px';
                span.style.cursor = 'pointer';

                span.addEventListener('click', function () {
                    const allResultSpans = document.querySelectorAll('#hanzi-result span');
                    allResultSpans.forEach(singleSpan => {
                        singleSpan.classList.remove('hanzi-selected');
                    });
                    this.classList.add('hanzi-selected');
                    const selectedChar = this.textContent;
                    const searchUrl = hanziAjax.home_url + '?s=' + encodeURIComponent(selectedChar) + '&post_type=glossary';
                    window.location.href = searchUrl;
                    
                    // Đóng popup sau khi chuyển hướng (dù không cần thiết nhưng là good practice)
                    closePopup();
                });

                resultDiv.appendChild(span);
            });
        }
    });

    if (clearButton) { // Đảm bảo clearButton tồn tại
        clearButton.addEventListener('click', function () {
            can.erase();
            document.getElementById('hanzi-result').innerHTML = '';
        });
    }
    
    canvasElement.addEventListener('mouseup', function () {
        can.recognize();
    });
    canvasElement.addEventListener('touchend', function () {
        can.recognize();
    });
});